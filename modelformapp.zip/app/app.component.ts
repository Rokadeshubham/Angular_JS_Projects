import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles: [`input.ng-invalid.ng-touched{border-left:5px solid red},
            
  `]
})
export class AppComponent implements OnInit {
  title = 'modelform';
  signupForm: FormGroup;
  genders = ['male','female'];

    ngOnInit(){

    this.signupForm = new FormGroup({
      'username': new FormControl(null,Validators.required),
      'email': new FormControl(null,[Validators.required,Validators.email]),
     

      'address':new FormGroup({
          'city':new FormControl(null,Validators.required),
          'street':new FormControl(null,Validators.required)
      }),
      'gender': new FormControl('male'),
      'age': new FormControl(null,[Validators.required,Validators.min(3)])
    });  
    }
    onSubmit(){
      console.log(this.signupForm);
    }
  



}
